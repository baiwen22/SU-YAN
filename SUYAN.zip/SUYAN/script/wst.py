import os

def script_4():
    print("\n")

    # 获取用户输入的文件夹路径
    folder_path = input("请输入小包文件夹路径: ")

    # 获取用户输入的固定特征码
    fixed_hex = input("请输入最新特征码（自己找）: ")

    # 获取用户输入的数组文件路径
    array_file_path = input("请输入包含数组的文件路径: ")

    # 读取数组文件内容
    def read_array_from_file(file_path):
        array = []
        try:
            with open(file_path, 'r') as file:
                for line in file:
                    line = line.strip()
                    if not line:
                        continue  # 跳过空行
                    parts = line.split(',')
                    if len(parts) != 2:
                        print(f"忽略格式错误的行: {line}")
                        continue
                    try:
                        a = int(parts[0])
                        b = int(parts[1])
                        array.append([a, b])
                    except ValueError:
                        print(f"无法转换为整数: {line}")
                        continue
        except Exception as e:
            print(f"读取或解析数组文件时出错: {e}")
            return []
        return array

    # 定义 DEC_to_HEX 函数
    def DEC_to_HEX(decimal_number):
        hex_number = format(int(decimal_number), '08X')
        hex_array = [hex_number[i:i + 2] for i in range(0, len(hex_number), 2)]
        reversed_hex_array = hex_array[::-1]
        reversed_hex_number = ''.join(reversed_hex_array)
        print(decimal_number, end=': ')
        print("转换为：", end='')
        print(reversed_hex_number)
        return reversed_hex_number

    # 定义 modify_file_hex 函数
    def modify_file_hex(file_contents, A, B, fixed_hex):
        search_seq1 = bytes.fromhex(A)
        search_seq2 = bytes.fromhex(B)
        fixed_hex = bytes.fromhex(fixed_hex)

        search_index1 = file_contents.find(search_seq1)
        search_index2 = file_contents.find(search_seq2)

        if search_index1 == -1 or search_index2 == -1:
            print("未找到指定的搜索序列。")
            return file_contents

        start_index1 = find_hex_reverse(file_contents, fixed_hex, search_index1)
        if start_index1 == -1:
            print(f"未找到十六进制数 {fixed_hex.hex()}")
            return file_contents

        start_index2 = find_hex_reverse(file_contents, fixed_hex, search_index2)
        if start_index2 == -1:
            print(f"未找到十六进制数 {fixed_hex.hex()}")
            return file_contents

        data_to_replace1 = file_contents[start_index1 - 8:start_index1]
        data_to_replace2 = file_contents[start_index2 - 8:start_index2]

        new_contents = bytearray(file_contents)
        new_contents[start_index1 - 8:start_index1] = data_to_replace2
        new_contents[start_index2 - 8:start_index2] = data_to_replace1

        return new_contents

    # 辅助函数，用于从给定位置向上查找十六进制数
    def find_hex_reverse(data, hex_to_find, start):
        return data.rfind(hex_to_find, 0, start)

    # 合并文件夹中的所有文件内容
    def merge_files_in_folder(folder_path):
        merged_content = bytearray()
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            if os.path.isfile(file_path):
                with open(file_path, "rb") as file:
                    merged_content += file.read()
        return merged_content

    # 将修改后的内容写回原来的文件
    def write_back_to_files(folder_path, modified_content, original_files):
        offset = 0
        for filename in original_files:
            file_path = os.path.join(folder_path, filename)
            if os.path.isfile(file_path):
                with open(file_path, "rb") as file:
                    file_size = len(file.read())
                with open(file_path, "wb") as file:
                    file.write(modified_content[offset:offset + file_size])
                offset += file_size

    # 读取数组文件内容
    array = read_array_from_file(array_file_path)

    # 合并文件夹中的所有文件内容
    original_files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
    merged_content = merge_files_in_folder(folder_path)

    # 对合并后的内容进行操作
    for i in range(len(array)):
        A = DEC_to_HEX(array[i][0])
        B = DEC_to_HEX(array[i][1])
        merged_content = modify_file_hex(merged_content, A, B, fixed_hex)

    # 将修改后的内容写回原来的文件
    write_back_to_files(folder_path, merged_content, original_files)

    print("文件夹中的所有文件已编辑")

if __name__ == "__main__":
    script_4()
